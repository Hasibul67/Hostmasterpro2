import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Globe, Activity, Clock, Users, ExternalLink, Play, Square } from "lucide-react";
import { cn } from "@/lib/utils";

interface DeploymentStatusProps {
  project: any;
  isRunning: boolean;
  onToggleRunning: () => void;
}

export default function DeploymentStatus({ project, isRunning, onToggleRunning }: DeploymentStatusProps) {
  const [uptime, setUptime] = useState(0);
  const [requests, setRequests] = useState(0);

  useEffect(() => {
    if (isRunning) {
      const interval = setInterval(() => {
        setUptime(prev => prev + 1);
        // Simulate random requests
        if (Math.random() < 0.3) {
          setRequests(prev => prev + Math.floor(Math.random() * 3) + 1);
        }
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isRunning]);

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${secs}s`;
    } else {
      return `${secs}s`;
    }
  };

  return (
    <Card className="border-0 bg-muted/20">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center justify-between">
          <span>Deployment Status</span>
          <Badge 
            className={cn(
              "text-xs",
              isRunning ? "bg-green-100 text-green-800 border-green-300" : "bg-gray-100 text-gray-800"
            )}
          >
            <div className={cn(
              "w-2 h-2 rounded-full mr-1",
              isRunning ? "bg-green-500 animate-pulse" : "bg-gray-400"
            )} />
            {isRunning ? "ONLINE" : "OFFLINE"}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Globe className="h-3 w-3 text-muted-foreground" />
            <span>URL</span>
          </div>
          {project.deploymentUrl ? (
            <a 
              href={project.deploymentUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline flex items-center gap-1 text-xs"
            >
              View Live
              <ExternalLink className="h-3 w-3" />
            </a>
          ) : (
            <span className="text-xs text-muted-foreground">Not deployed</span>
          )}
        </div>

        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Clock className="h-3 w-3 text-muted-foreground" />
            <span>Uptime</span>
          </div>
          <span className="text-xs font-mono">{formatUptime(uptime)}</span>
        </div>

        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Activity className="h-3 w-3 text-muted-foreground" />
            <span>Requests</span>
          </div>
          <span className="text-xs font-mono">{requests.toLocaleString()}</span>
        </div>

        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <Users className="h-3 w-3 text-muted-foreground" />
            <span>Users</span>
          </div>
          <span className="text-xs font-mono">{Math.floor(requests / 3) || 0}</span>
        </div>

        <div className="pt-2">
          <Button
            variant={isRunning ? "destructive" : "default"}
            size="sm"
            onClick={onToggleRunning}
            className="w-full h-8"
          >
            {isRunning ? (
              <>
                <Square className="h-3 w-3 mr-1" />
                Stop
              </>
            ) : (
              <>
                <Play className="h-3 w-3 mr-1" />
                Start
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}