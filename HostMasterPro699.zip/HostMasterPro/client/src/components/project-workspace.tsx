import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";
import { Terminal, Globe, Settings, Play, Square, RefreshCw, ExternalLink } from "lucide-react";
import FileExplorer from "./file-explorer";
import CodeEditor from "./code-editor";
import DeploymentStatus from "./deployment-status";
import BotPreview from "./bot-preview";
import { getTelegramBotCode, getTelegramPackageJson } from "./telegram-bot-template";
import { cn } from "@/lib/utils";
import type { Project } from "@shared/schema";

interface FileNode {
  id: string;
  name: string;
  type: "file" | "folder";
  content?: string;
  children?: FileNode[];
}

interface ProjectWorkspaceProps {
  project: Project;
  isOpen: boolean;
  onClose: () => void;
}

const getDefaultFiles = (language: string, projectName: string): FileNode[] => {
  const isBot = projectName.toLowerCase().includes('bot') || language === 'telegram-bot';
  
  const baseFiles: FileNode[] = [
    {
      id: "readme",
      name: "README.md",
      type: "file",
      content: `# ${projectName}

${isBot ? `🤖 Telegram Bot powered by BotHost Pro

## Bot Features
- Welcome messages for new users
- Admin control panel
- Real-time statistics
- Broadcasting capabilities
- Health monitoring

## Bot Token
- Token: 7874841404:AAFZpvo2-iHPubtT43WcxMLNO2cIlN6nxEY
- Admin ID: 7476183212

## Commands
- /start - Welcome message
- /help - Show all commands
- /status - Bot statistics
- /admin - Admin panel (Admin only)

Start chatting with your bot on Telegram!` : `Welcome to your ${language} project!

## Getting Started

1. Edit your files in the editor
2. Click "Run" to test your application
3. Deploy when ready`}

Happy coding!
`
    }
  ];

  switch (language) {
    case "nodejs":
      if (isBot) {
        return [
          {
            id: "package",
            name: "package.json",
            type: "file",
            content: getTelegramPackageJson(projectName)
          },
          {
            id: "bot",
            name: "bot.js",
            type: "file",
            content: getTelegramBotCode("7874841404:AAFZpvo2-iHPubtT43WcxMLNO2cIlN6nxEY", "7476183212", projectName)
          },
          ...baseFiles
        ];
      } else {
        return [
          {
            id: "package",
            name: "package.json",
            type: "file",
            content: `{
  "name": "${projectName.toLowerCase().replace(/\s+/g, '-')}",
  "version": "1.0.0",
  "description": "A Node.js project",
  "main": "index.js",
  "scripts": {
    "start": "node index.js",
    "dev": "node index.js"
  },
  "dependencies": {
    "express": "^4.18.0"
  }
}`
          },
          {
            id: "index",
            name: "index.js",
            type: "file",
            content: `const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.json({ 
    message: 'Hello from ${projectName}!',
    timestamp: new Date().toISOString()
  });
});

app.listen(port, () => {
  console.log(\`Server running on port \${port}\`);
});`
          },
          ...baseFiles
        ];
      }

    case "python":
      return [
        {
          id: "requirements",
          name: "requirements.txt",
          type: "file",
          content: `fastapi==0.104.1
uvicorn==0.24.0`
        },
        {
          id: "main",
          name: "main.py",
          type: "file",
          content: `from fastapi import FastAPI
from datetime import datetime

app = FastAPI(title="${projectName}")

@app.get("/")
def read_root():
    return {
        "message": "Hello from ${projectName}!",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/health")
def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)`
        },
        ...baseFiles
      ];

    case "php":
      return [
        {
          id: "index",
          name: "index.php",
          type: "file",
          content: `<?php
header('Content-Type: application/json');

$response = [
    'message' => 'Hello from ${projectName}!',
    'timestamp' => date('c'),
    'php_version' => phpversion()
];

echo json_encode($response, JSON_PRETTY_PRINT);
?>`
        },
        {
          id: "composer",
          name: "composer.json",
          type: "file",
          content: `{
    "name": "${projectName.toLowerCase().replace(/\s+/g, '-')}",
    "description": "A PHP project",
    "type": "project",
    "require": {
        "php": ">=8.0"
    }
}`
        },
        ...baseFiles
      ];

    case "html":
      return [
        {
          id: "index",
          name: "index.html",
          type: "file",
          content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${projectName}</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to ${projectName}</h1>
        <p>Your static website is ready!</p>
        <button onclick="showMessage()">Click me!</button>
    </div>
    <script src="script.js"></script>
</body>
</html>`
        },
        {
          id: "style",
          name: "style.css",
          type: "file",
          content: `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    line-height: 1.6;
    color: #333;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.container {
    text-align: center;
    background: white;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    max-width: 500px;
}

h1 {
    color: #667eea;
    margin-bottom: 1rem;
}

button {
    background: #667eea;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top: 1rem;
}

button:hover {
    background: #5a6fd8;
}`
        },
        {
          id: "script",
          name: "script.js",
          type: "file",
          content: `function showMessage() {
    alert('Hello from ${projectName}!');
}

console.log('${projectName} loaded successfully!');`
        },
        ...baseFiles
      ];

    case "react":
      return [
        {
          id: "package",
          name: "package.json",
          type: "file",
          content: `{
  "name": "${projectName.toLowerCase().replace(/\s+/g, '-')}",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build"
  }
}`
        },
        {
          id: "app",
          name: "App.jsx",
          type: "file",
          content: `import React, { useState } from 'react';
import './App.css';

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="App">
      <header className="App-header">
        <h1>Welcome to ${projectName}</h1>
        <p>Your React app is ready!</p>
        <div className="counter">
          <button onClick={() => setCount(count - 1)}>-</button>
          <span>{count}</span>
          <button onClick={() => setCount(count + 1)}>+</button>
        </div>
      </header>
    </div>
  );
}

export default App;`
        },
        {
          id: "app-css",
          name: "App.css",
          type: "file",
          content: `.App {
  text-align: center;
}

.App-header {
  background-color: #282c34;
  padding: 20px;
  color: white;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.counter {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-top: 2rem;
}

.counter button {
  background: #61dafb;
  border: none;
  padding: 10px 20px;
  border-radius: 5px;
  font-size: 18px;
  cursor: pointer;
}

.counter span {
  font-size: 24px;
  font-weight: bold;
}`
        },
        ...baseFiles
      ];

    case "go":
      return [
        {
          id: "go-mod",
          name: "go.mod",
          type: "file",
          content: `module ${projectName.toLowerCase().replace(/\s+/g, '-')}

go 1.21`
        },
        {
          id: "main",
          name: "main.go",
          type: "file",
          content: `package main

import (
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "time"
)

type Response struct {
    Message   string \`json:"message"\`
    Timestamp string \`json:"timestamp"\`
}

func handler(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Content-Type", "application/json")
    
    response := Response{
        Message:   "Hello from ${projectName}!",
        Timestamp: time.Now().Format(time.RFC3339),
    }
    
    json.NewEncoder(w).Encode(response)
}

func main() {
    http.HandleFunc("/", handler)
    fmt.Println("Server starting on :8080")
    log.Fatal(http.ListenAndServe(":8080", nil))
}`
        },
        ...baseFiles
      ];

    default:
      return baseFiles;
  }
};

export default function ProjectWorkspace({ project, isOpen, onClose }: ProjectWorkspaceProps) {
  const [files, setFiles] = useState<FileNode[]>([]);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    if (isOpen && project) {
      const defaultFiles = getDefaultFiles(project.language, project.name);
      setFiles(defaultFiles);
      setSelectedFile(defaultFiles[0]);
      setLogs([
        `[${new Date().toLocaleTimeString()}] 🚀 Welcome to ${project.name}!`,
        `[${new Date().toLocaleTimeString()}] 📁 ${defaultFiles.length} files loaded`,
        `[${new Date().toLocaleTimeString()}] 💡 Click "Run" to start your ${project.language} project`,
      ]);
    }
  }, [isOpen, project]);

  const handleFileCreate = (name: string, type: "file" | "folder", parentId?: string) => {
    const newFile: FileNode = {
      id: Math.random().toString(36).substring(2),
      name,
      type,
      content: type === "file" ? "" : undefined,
      children: type === "folder" ? [] : undefined
    };

    if (parentId) {
      // Add to parent folder (simplified implementation)
      setFiles(prev => [...prev, newFile]);
    } else {
      setFiles(prev => [...prev, newFile]);
    }
  };

  const handleFileDelete = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
    if (selectedFile?.id === id) {
      setSelectedFile(null);
    }
  };

  const handleFileRename = (id: string, newName: string) => {
    setFiles(prev => 
      prev.map(f => f.id === id ? { ...f, name: newName } : f)
    );
  };

  const handleFileSave = (content: string) => {
    if (selectedFile) {
      setFiles(prev =>
        prev.map(f => f.id === selectedFile.id ? { ...f, content } : f)
      );
    }
  };

  const handleRun = () => {
    setIsRunning(true);
    setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] 🚀 Starting ${project.language} development server...`]);
    
    // Language-specific run simulation
    const getRunMessages = (language: string) => {
      switch (language) {
        case "nodejs":
          const isBot = project.name.toLowerCase().includes('bot');
          if (isBot) {
            return [
              "📦 npm install",
              "📦 Installing node-telegram-bot-api@^0.61.0",
              "📦 Installing express@^4.18.2",
              "🤖 Initializing Telegram bot...",
              "🔐 Connecting to Telegram API...",
              "📡 Setting up webhook...",
              "🚀 Bot server starting...",
              "✅ Telegram bot is online!",
              "👑 Admin notification sent",
              `🌐 Bot dashboard: ${project.deploymentUrl}`,
              "🎯 Ready to receive messages!",
            ];
          } else {
            return [
              "📦 npm install",
              "📦 Installing express@^4.18.0",
              "⚡ Starting Node.js server...",
              "🚀 Express server initializing...",
              "📡 Server binding to port 3000",
              "✅ Express server running on port 3000",
              "🔗 API endpoints available",
              `🌐 Your app is live at: ${project.deploymentUrl}`,
              "🎯 Ready to accept requests!",
            ];
          }
        case "python":
          return [
            "📦 pip install -r requirements.txt",
            "⚡ Starting FastAPI server...",
            "✅ Uvicorn server running on port 8000",
            `🌐 Your API is live at: ${project.deploymentUrl}`,
          ];
        case "php":
          return [
            "📦 composer install",
            "⚡ Starting PHP server...",
            "✅ PHP server running on port 80",
            `🌐 Your site is live at: ${project.deploymentUrl}`,
          ];
        case "react":
          return [
            "📦 npm install",
            "⚡ Building React app...",
            "✅ Development server started",
            `🌐 Your React app is live at: ${project.deploymentUrl}`,
          ];
        case "go":
          return [
            "📦 go mod tidy",
            "⚡ Building Go application...",
            "✅ Go server running on port 8080",
            `🌐 Your app is live at: ${project.deploymentUrl}`,
          ];
        default:
          return [
            "📦 Setting up environment...",
            "⚡ Starting application...",
            "✅ Application is running!",
            `🌐 Available at: ${project.deploymentUrl}`,
          ];
      }
    };

    const runMessages = getRunMessages(project.language);

    runMessages.forEach((message, index) => {
      setTimeout(() => {
        setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`]);
        if (index === runMessages.length - 1) {
          setIsRunning(false);
          // Update project status to online when run completes
          setTimeout(() => {
            const isBot = project.name.toLowerCase().includes('bot');
            setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] 🎉 Deployment completed successfully!`]);
            setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] 📊 Project status: ONLINE`]);
            if (isBot) {
              setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] 🤖 Telegram bot active and responding`]);
              setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] 👑 Admin controls ready (ID: 7476183212)`]);
              setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] 💬 Bot ready to receive messages`]);
            } else {
              setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] 🔄 Health check: PASSED`]);
              setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] 🌍 Global CDN: ACTIVE`]);
            }
          }, 1000);
        }
      }, (index + 1) * 600);
    });
  };

  const getLanguageIcon = (language: string) => {
    switch (language) {
      case "nodejs": return "🟢";
      case "python": return "🐍";
      case "php": return "🐘";
      case "html": return "🌐";
      case "react": return "⚛️";
      case "go": return "🐹";
      default: return "📦";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[100vw] max-h-[100vh] w-[100vw] h-[100vh] p-0 m-0 rounded-none">
        <DialogHeader className="p-4 border-b bg-background/95 backdrop-blur">
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{getLanguageIcon(project.language)}</span>
              <div>
                <div className="flex items-center gap-2">
                  <span>{project.name}</span>
                  <Badge variant="secondary" className="text-xs">
                    {project.language}
                  </Badge>
                  <Badge 
                    className={cn(
                      "text-xs",
                      project.status === "online" ? "bg-green-100 text-green-800" : 
                      project.status === "building" ? "bg-yellow-100 text-yellow-800" :
                      "bg-gray-100 text-gray-800"
                    )}
                  >
                    {project.status}
                  </Badge>
                </div>
                {project.deploymentUrl && (
                  <div className="flex items-center gap-2 mt-1">
                    <Globe className="h-3 w-3 text-muted-foreground" />
                    <a 
                      href={project.deploymentUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                    >
                      {project.deploymentUrl}
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                )}
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              ← Back to Dashboard
            </Button>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-hidden">
          <ResizablePanelGroup direction="horizontal" className="h-[calc(100vh-100px)]">
            {/* File Explorer */}
            <ResizablePanel defaultSize={25} minSize={20}>
              <Card className="h-full rounded-none border-0 border-r">
                <FileExplorer
                  files={files}
                  onFileSelect={setSelectedFile}
                  onFileCreate={handleFileCreate}
                  onFileDelete={handleFileDelete}
                  onFileRename={handleFileRename}
                  selectedFileId={selectedFile?.id}
                />
              </Card>
            </ResizablePanel>

            <ResizableHandle />

            {/* Editor and Terminal */}
            <ResizablePanel defaultSize={75}>
              <ResizablePanelGroup direction="vertical">
                {/* Code Editor */}
                <ResizablePanel defaultSize={70} minSize={40}>
                  <CodeEditor
                    file={selectedFile}
                    onSave={handleFileSave}
                    onRun={handleRun}
                    language={project.language}
                  />
                </ResizablePanel>

                <ResizableHandle />

                {/* Terminal/Console */}
                <ResizablePanel defaultSize={30} minSize={20}>
                  <Card className="h-full rounded-none border-0 border-t">
                    <Tabs defaultValue="console" className="h-full">
                      <div className="flex items-center justify-between p-2 border-b">
                        <TabsList className="grid w-full grid-cols-3 max-w-[300px]">
                          <TabsTrigger value="console" className="text-xs">Console</TabsTrigger>
                          <TabsTrigger value="preview" className="text-xs">
                            {project.name.toLowerCase().includes('bot') ? '🤖 Bot' : 'Preview'}
                          </TabsTrigger>
                          <TabsTrigger value="status" className="text-xs">Status</TabsTrigger>
                        </TabsList>
                        
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={handleRun}
                            disabled={isRunning}
                            className="h-7 px-2"
                          >
                            {isRunning ? (
                              <RefreshCw className="h-3 w-3 animate-spin mr-1" />
                            ) : (
                              <Play className="h-3 w-3 mr-1" />
                            )}
                            {isRunning ? "Running..." : "Run"}
                          </Button>
                        </div>
                      </div>

                      <TabsContent value="console" className="m-0 h-[calc(100%-50px)]">
                        <div className="h-full bg-gray-900 text-green-400 font-mono text-xs p-3 overflow-auto">
                          {logs.map((log, index) => (
                            <div key={index} className="mb-1 animate-in fade-in duration-300">
                              {log}
                            </div>
                          ))}
                          {isRunning && (
                            <div className="flex items-center gap-2 text-yellow-400">
                              <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                              Processing...
                            </div>
                          )}
                        </div>
                      </TabsContent>

                      <TabsContent value="preview" className="m-0 h-[calc(100%-50px)]">
                        <div className="h-full bg-white dark:bg-gray-900 border rounded-sm">
                          {project.name.toLowerCase().includes('bot') ? (
                            <BotPreview 
                              project={project}
                              isRunning={!isRunning && logs.some(log => log.includes('ONLINE'))}
                            />
                          ) : project.deploymentUrl ? (
                            <iframe
                              src={project.deploymentUrl}
                              className="w-full h-full border-0"
                              title="Project Preview"
                            />
                          ) : (
                            <div className="flex items-center justify-center h-full text-muted-foreground">
                              <div className="text-center">
                                <Globe className="h-8 w-8 mx-auto mb-2 opacity-50" />
                                <p>Deploy your project to see the preview</p>
                              </div>
                            </div>
                          )}
                        </div>
                      </TabsContent>

                      <TabsContent value="status" className="m-0 h-[calc(100%-50px)]">
                        <div className="p-3 h-full overflow-auto">
                          <DeploymentStatus 
                            project={project}
                            isRunning={!isRunning && logs.some(log => log.includes('ONLINE'))}
                            onToggleRunning={() => {
                              if (logs.some(log => log.includes('ONLINE'))) {
                                setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] 🛑 Stopping server...`]);
                                setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] 📊 Project status: OFFLINE`]);
                              } else {
                                handleRun();
                              }
                            }}
                          />
                        </div>
                      </TabsContent>
                    </Tabs>
                  </Card>
                </ResizablePanel>
              </ResizablePanelGroup>
            </ResizablePanel>
          </ResizablePanelGroup>
        </div>
      </DialogContent>
    </Dialog>
  );
}