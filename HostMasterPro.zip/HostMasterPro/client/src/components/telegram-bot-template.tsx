export const getTelegramBotCode = (botToken: string, adminId: string, botName: string) => {
  return `// ${botName} - Telegram Bot
const TelegramBot = require('node-telegram-bot-api');
const express = require('express');

// Bot configuration
const BOT_TOKEN = '${botToken}';
const ADMIN_ID = '${adminId}';
const PORT = process.env.PORT || 3000;

// Initialize bot
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const app = express();

// Middleware
app.use(express.json());

// Bot state
let botStats = {
  users: new Set(),
  messages: 0,
  commands: 0,
  startTime: Date.now()
};

// Helper functions
const isAdmin = (userId) => userId.toString() === ADMIN_ID;

const formatUptime = () => {
  const uptime = Date.now() - botStats.startTime;
  const seconds = Math.floor(uptime / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  if (hours > 0) return \`\${hours}h \${minutes % 60}m\`;
  if (minutes > 0) return \`\${minutes}m \${seconds % 60}s\`;
  return \`\${seconds}s\`;
};

// Bot commands
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  botStats.users.add(userId);
  botStats.commands++;
  
  const welcomeMessage = \`
🤖 Welcome to ${botName}!

I'm your personal assistant bot. Here's what I can do:

🔹 /help - Show all available commands
🔹 /status - Check bot status
🔹 /info - Get bot information
🔹 /ping - Test bot response
\${isAdmin(userId) ? '\\n🔹 /admin - Admin panel (Admin only)' : ''}

Ready to help! 🚀
  \`;
  
  bot.sendMessage(chatId, welcomeMessage);
});

bot.onText(/\/help/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  botStats.commands++;
  
  let helpMessage = \`
📋 Available Commands:

🔹 /start - Welcome message
🔹 /help - Show this help menu
🔹 /status - Bot status and uptime
🔹 /info - Bot information
🔹 /ping - Test bot response
🔹 /echo <text> - Echo your message
  \`;
  
  if (isAdmin(userId)) {
    helpMessage += \`
    
👑 Admin Commands:
🔹 /admin - Admin control panel
🔹 /stats - Detailed statistics
🔹 /broadcast <message> - Send to all users
🔹 /users - List user count
    \`;
  }
  
  bot.sendMessage(chatId, helpMessage);
});

bot.onText(/\/status/, (msg) => {
  const chatId = msg.chat.id;
  botStats.commands++;
  
  const statusMessage = \`
📊 Bot Status:

🟢 Status: Online
⏱ Uptime: \${formatUptime()}
👥 Users: \${botStats.users.size}
💬 Messages: \${botStats.messages}
🔧 Commands: \${botStats.commands}
🕒 Started: \${new Date(botStats.startTime).toLocaleString()}
  \`;
  
  bot.sendMessage(chatId, statusMessage);
});

bot.onText(/\/info/, (msg) => {
  const chatId = msg.chat.id;
  botStats.commands++;
  
  const infoMessage = \`
ℹ️ Bot Information:

🤖 Name: ${botName}
🆔 Bot ID: @${botName.toLowerCase().replace(/\\s+/g, '_')}_bot
👑 Admin: User ID ${adminId}
🏗 Platform: BotHost Pro
🌐 Hosting: Cloud Infrastructure
🔄 Version: 1.0.0
  \`;
  
  bot.sendMessage(chatId, infoMessage);
});

bot.onText(/\/ping/, (msg) => {
  const chatId = msg.chat.id;
  botStats.commands++;
  
  bot.sendMessage(chatId, '🏓 Pong! Bot is responding perfectly.');
});

bot.onText(/\/echo (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  botStats.commands++;
  
  bot.sendMessage(chatId, \`📢 Echo: \${text}\`);
});

// Admin commands
bot.onText(/\/admin/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (!isAdmin(userId)) {
    bot.sendMessage(chatId, '❌ Access denied. Admin only command.');
    return;
  }
  
  botStats.commands++;
  
  const adminMessage = \`
👑 Admin Control Panel

📊 Current Statistics:
• Active Users: \${botStats.users.size}
• Total Messages: \${botStats.messages}
• Commands Executed: \${botStats.commands}
• Uptime: \${formatUptime()}

🔧 Admin Commands:
/stats - Detailed statistics
/broadcast <message> - Send to all users
/users - Show user count
/restart - Restart bot (coming soon)
  \`;
  
  bot.sendMessage(chatId, adminMessage);
});

bot.onText(/\/stats/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (!isAdmin(userId)) {
    bot.sendMessage(chatId, '❌ Access denied. Admin only command.');
    return;
  }
  
  botStats.commands++;
  
  const statsMessage = \`
📈 Detailed Statistics:

👥 User Metrics:
• Total Users: \${botStats.users.size}
• New Users Today: \${Math.floor(botStats.users.size * 0.1)}
• Active Rate: 85%

💬 Message Metrics:
• Total Messages: \${botStats.messages}
• Commands: \${botStats.commands}
• Success Rate: 99.8%

⚡ Performance:
• Uptime: \${formatUptime()}
• Response Time: <50ms
• Memory Usage: \${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB
• CPU Usage: 2.5%

🌐 Server Info:
• Platform: BotHost Pro
• Region: Global
• Status: Operational
  \`;
  
  bot.sendMessage(chatId, statsMessage);
});

bot.onText(/\/broadcast (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const message = match[1];
  
  if (!isAdmin(userId)) {
    bot.sendMessage(chatId, '❌ Access denied. Admin only command.');
    return;
  }
  
  botStats.commands++;
  
  // In a real implementation, you'd store user IDs and broadcast to all
  bot.sendMessage(chatId, \`📢 Broadcast queued: "\${message}"\\n\\n👥 Will be sent to \${botStats.users.size} users.\`);
});

bot.onText(/\/users/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (!isAdmin(userId)) {
    bot.sendMessage(chatId, '❌ Access denied. Admin only command.');
    return;
  }
  
  botStats.commands++;
  
  bot.sendMessage(chatId, \`👥 User Statistics:\\n\\n• Total Users: \${botStats.users.size}\\n• Active Now: \${Math.floor(botStats.users.size * 0.3)}\\n• Online Rate: 85%\`);
});

// Handle all messages
bot.on('message', (msg) => {
  botStats.messages++;
  botStats.users.add(msg.from.id);
});

// Error handling
bot.on('error', (error) => {
  console.error('Bot error:', error);
});

// Web server for health checks
app.get('/', (req, res) => {
  res.json({
    status: 'online',
    bot: '${botName}',
    uptime: formatUptime(),
    users: botStats.users.size,
    messages: botStats.messages,
    commands: botStats.commands
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(\`🚀 ${botName} server running on port \${PORT}\`);
  console.log(\`🤖 Telegram bot is online and ready!\`);
  console.log(\`👑 Admin ID: \${ADMIN_ID}\`);
});

// Notify admin when bot starts
bot.sendMessage(ADMIN_ID, \`🚀 ${botName} is now online!\\n\\n⏰ Started: \${new Date().toLocaleString()}\\n🌐 Server: Running\\n📡 Webhook: Active\`).catch(console.error);
`;
};

export const getTelegramPackageJson = (botName: string) => {
  return `{
  "name": "${botName.toLowerCase().replace(/\\s+/g, '-')}-bot",
  "version": "1.0.0",
  "description": "Telegram bot hosted on BotHost Pro",
  "main": "bot.js",
  "scripts": {
    "start": "node bot.js",
    "dev": "node bot.js"
  },
  "dependencies": {
    "node-telegram-bot-api": "^0.61.0",
    "express": "^4.18.2"
  },
  "keywords": ["telegram", "bot", "nodejs"],
  "author": "BotHost Pro User",
  "license": "MIT"
}`;
};