import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Code, Globe, Database, Smartphone, Server, Layers } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

interface ProjectCreationModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: number;
}

const languageTemplates = [
  {
    id: "nodejs",
    name: "Node.js",
    description: "JavaScript runtime with npm packages",
    icon: Code,
    color: "text-green-600",
    frameworks: ["Express", "Telegram Bot", "Fastify", "NestJS"],
    example: "Web APIs, Telegram bots, REST services"
  },
  {
    id: "python",
    name: "Python",
    description: "Versatile language with pip packages",
    icon: Code,
    color: "text-blue-600", 
    frameworks: ["FastAPI", "Flask", "Django", "Tornado"],
    example: "AI/ML apps, web scrapers, data analysis"
  },
  {
    id: "php",
    name: "PHP",
    description: "Server-side scripting with composer",
    icon: Server,
    color: "text-purple-600",
    frameworks: ["Laravel", "Symfony", "CodeIgniter", "Slim"],
    example: "WordPress, CMS, web applications"
  },
  {
    id: "html",
    name: "Static HTML",
    description: "Frontend websites with CSS/JS",
    icon: Globe,
    color: "text-orange-600",
    frameworks: ["Vanilla", "Bootstrap", "Tailwind CSS"],
    example: "Landing pages, portfolios, documentation"
  },
  {
    id: "react",
    name: "React",
    description: "Modern frontend framework",
    icon: Layers,
    color: "text-cyan-600",
    frameworks: ["Create React App", "Next.js", "Vite"],
    example: "SPAs, dashboards, interactive UIs"
  },
  {
    id: "go",
    name: "Go",
    description: "Fast, compiled language",
    icon: Database,
    color: "text-blue-400",
    frameworks: ["Gin", "Echo", "Fiber", "Chi"],
    example: "Microservices, APIs, CLI tools"
  }
];

export default function ProjectCreationModal({ isOpen, onClose, userId }: ProjectCreationModalProps) {
  const [selectedLanguage, setSelectedLanguage] = useState<string>("nodejs");
  const [projectName, setProjectName] = useState("");
  const [framework, setFramework] = useState("");
  const [repositoryUrl, setRepositoryUrl] = useState("");
  const [description, setDescription] = useState("");
  const [isPublic, setIsPublic] = useState(true);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createProjectMutation = useMutation({
    mutationFn: (projectData: any) =>
      apiRequest("POST", "/api/projects", projectData),
    onSuccess: (newProject) => {
      toast({
        title: "Project Created Successfully!",
        description: "Opening your development workspace...",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      onClose();
      resetForm();
      // Trigger workspace opening
      if (window.openProjectWorkspace) {
        window.openProjectWorkspace(newProject);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error Creating Project",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setProjectName("");
    setFramework("");
    setRepositoryUrl("");
    setDescription("");
    setSelectedLanguage("nodejs");
    setIsPublic(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectName || !selectedLanguage) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    createProjectMutation.mutate({
      name: projectName,
      language: selectedLanguage,
      framework: framework || null,
      repositoryUrl: repositoryUrl || null,
      userId,
      isPublic,
      status: "building"
    });
  };

  const selectedLanguageData = languageTemplates.find(t => t.id === selectedLanguage);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Code className="h-5 w-5" />
            Create New Project
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Language Selection */}
          <div className="space-y-4">
            <Label>Select Language/Platform</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {languageTemplates.map((template) => {
                const Icon = template.icon;
                return (
                  <div
                    key={template.id}
                    className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                      selectedLanguage === template.id
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                    onClick={() => {
                      setSelectedLanguage(template.id);
                      setFramework("");
                    }}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <Icon className={`h-5 w-5 ${template.color}`} />
                      <span className="font-medium text-sm">{template.name}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{template.description}</p>
                    <p className="text-xs text-muted-foreground mt-1 italic">{template.example}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Project Configuration */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="projectName">Project Name *</Label>
              <Input
                id="projectName"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                placeholder="my-awesome-project"
                required
              />
            </div>
            <div>
              <Label htmlFor="framework">Framework (Optional)</Label>
              <Select value={framework} onValueChange={setFramework}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose framework" />
                </SelectTrigger>
                <SelectContent>
                  {selectedLanguageData?.frameworks.map((fw) => (
                    <SelectItem key={fw} value={fw.toLowerCase()}>
                      {fw === "Telegram Bot" ? "🤖 Telegram Bot" : fw}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {framework === "telegram bot" && (
                <div className="mt-2 p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <p className="text-xs text-blue-700 dark:text-blue-300">
                    🤖 <strong>Telegram Bot Selected!</strong><br/>
                    Your bot will be automatically configured with:<br/>
                    • Token: 7874841404:AAFZpvo2-iHPubtT43WcxMLNO2cIlN6nxEY<br/>
                    • Admin ID: 7476183212<br/>
                    • Ready-to-use commands and admin panel
                  </p>
                </div>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="repositoryUrl">Repository URL (Optional)</Label>
            <Input
              id="repositoryUrl"
              value={repositoryUrl}
              onChange={(e) => setRepositoryUrl(e.target.value)}
              placeholder="https://github.com/username/repo"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Deploy from GitHub, GitLab, or any Git repository
            </p>
          </div>

          <div>
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your project..."
              rows={3}
            />
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="isPublic"
              checked={isPublic}
              onChange={(e) => setIsPublic(e.target.checked)}
              className="rounded"
            />
            <Label htmlFor="isPublic">Make project public (others can view)</Label>
          </div>

          {/* Framework Features */}
          {selectedLanguageData && (
            <div className="p-4 bg-muted/50 rounded-lg">
              <h4 className="font-medium mb-3 flex items-center gap-2">
                <selectedLanguageData.icon className={`h-4 w-4 ${selectedLanguageData.color}`} />
                {selectedLanguageData.name} Features
              </h4>
              <div className="grid grid-cols-2 gap-2">
                {selectedLanguageData.frameworks.map((fw, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {fw}
                  </Badge>
                ))}
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                ✓ Auto-deployment ✓ Custom domains ✓ Environment variables ✓ SSL certificates
              </p>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createProjectMutation.isPending}
              className="flex-1"
            >
              {createProjectMutation.isPending ? "Creating..." : "Create Project"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}