import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Bot, User, Crown, MessageCircle, Users, Activity, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";

interface BotPreviewProps {
  project: any;
  isRunning: boolean;
}

interface Message {
  id: string;
  from: "user" | "bot";
  text: string;
  timestamp: Date;
  isAdmin?: boolean;
}

export default function BotPreview({ project, isRunning }: BotPreviewProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [stats, setStats] = useState({
    users: 15,
    messages: 47,
    commands: 23,
    uptime: "2h 15m"
  });

  useEffect(() => {
    if (isRunning) {
      // Initialize with welcome messages
      const initialMessages: Message[] = [
        {
          id: "1",
          from: "bot",
          text: `🤖 ${project.name} is LIVE!\n\n✅ Bot Status: ONLINE\n🤖 Username: @Tg_oieieoorir_bot\nToken: 7874841404:AAFZpvo2-iHPubtT43WcxMLNO2cIlN6nxEY\nAdmin ID: 7476183212\n\n📋 Available Commands:\n🔹 /help - Show all commands\n🔹 /status - Bot statistics\n🔹 /ping - Test response\n🔹 /admin - Admin panel (Admin only)\n\nYour bot is now responding to messages on Telegram! 🚀`,
          timestamp: new Date(Date.now() - 300000)
        },
        {
          id: "2",
          from: "user",
          text: "/status",
          timestamp: new Date(Date.now() - 240000)
        },
        {
          id: "3",
          from: "bot",
          text: `📊 Bot Status:\n\n🟢 Status: Online\n⏱ Uptime: ${stats.uptime}\n👥 Users: ${stats.users}\n💬 Messages: ${stats.messages}\n🔧 Commands: ${stats.commands}\n🕒 Started: ${new Date().toLocaleString()}`,
          timestamp: new Date(Date.now() - 230000)
        },
        {
          id: "4",
          from: "user",
          text: "/admin",
          timestamp: new Date(Date.now() - 120000),
          isAdmin: true
        },
        {
          id: "5",
          from: "bot",
          text: `👑 Admin Control Panel\n\n📊 Current Statistics:\n• Active Users: ${stats.users}\n• Total Messages: ${stats.messages}\n• Commands Executed: ${stats.commands}\n• Uptime: ${stats.uptime}\n\n🔧 Admin Commands:\n/stats - Detailed statistics\n/broadcast <message> - Send to all users\n/users - Show user count`,
          timestamp: new Date(Date.now() - 110000)
        }
      ];
      
      setMessages(initialMessages);

      // Simulate live activity
      const interval = setInterval(() => {
        setStats(prev => ({
          ...prev,
          users: prev.users + Math.floor(Math.random() * 2),
          messages: prev.messages + Math.floor(Math.random() * 3) + 1,
          commands: prev.commands + (Math.random() < 0.3 ? 1 : 0)
        }));

        // Occasionally add new messages
        if (Math.random() < 0.2) {
          const newMessage: Message = {
            id: Date.now().toString(),
            from: "user",
            text: ["/ping", "/help", "/status", "Hello!", "How are things?"][Math.floor(Math.random() * 5)],
            timestamp: new Date()
          };
          
          setMessages(prev => [...prev, newMessage]);
          
          setTimeout(() => {
            const botResponse: Message = {
              id: (Date.now() + 1).toString(),
              from: "bot",
              text: newMessage.text === "/ping" ? "🏓 Pong! Bot is responding perfectly." :
                    newMessage.text === "/help" ? "📋 Available Commands:\n\n🔹 /start - Welcome message\n🔹 /help - Show this help menu\n🔹 /status - Bot status and uptime\n🔹 /info - Bot information\n🔹 /ping - Test bot response" :
                    newMessage.text === "/status" ? `📊 Bot Status:\n\n🟢 Status: Online\n⏱ Uptime: ${stats.uptime}\n👥 Users: ${stats.users}` :
                    "Thanks for your message! I'm here to help. Try /help to see what I can do! 😊",
              timestamp: new Date()
            };
            
            setMessages(prev => [...prev, botResponse]);
          }, 1000 + Math.random() * 2000);
        }
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [isRunning, project.name, stats.uptime, stats.users]);

  const handleSendMessage = () => {
    if (!inputMessage.trim() || !isRunning) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      from: "user",
      text: inputMessage,
      timestamp: new Date(),
      isAdmin: inputMessage.startsWith("/admin") || inputMessage.startsWith("/broadcast") || inputMessage.startsWith("/stats")
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");

    // Simulate bot response
    setTimeout(() => {
      let botResponse = "";
      
      if (inputMessage.startsWith("/")) {
        const command = inputMessage.toLowerCase();
        if (command === "/ping") {
          botResponse = "🏓 Pong! Bot is responding perfectly.";
        } else if (command === "/help") {
          botResponse = "📋 Available Commands:\n\n🔹 /start - Welcome message\n🔹 /help - Show this help menu\n🔹 /status - Bot status and uptime\n🔹 /info - Bot information\n🔹 /ping - Test bot response\n🔹 /echo <text> - Echo your message";
        } else if (command === "/status") {
          botResponse = `📊 Bot Status:\n\n🟢 Status: Online\n⏱ Uptime: ${stats.uptime}\n👥 Users: ${stats.users}\n💬 Messages: ${stats.messages}\n🔧 Commands: ${stats.commands}`;
        } else if (command === "/admin") {
          botResponse = `👑 Admin Control Panel\n\n📊 Current Statistics:\n• Active Users: ${stats.users}\n• Total Messages: ${stats.messages}\n• Commands Executed: ${stats.commands}\n• Uptime: ${stats.uptime}\n\n🔧 Admin Commands:\n/stats - Detailed statistics\n/broadcast <message> - Send to all users\n/users - Show user count`;
        } else if (command.startsWith("/broadcast")) {
          botResponse = `📢 Broadcast queued: "${inputMessage.slice(11)}"\n\n👥 Will be sent to ${stats.users} users.`;
        } else {
          botResponse = "❓ Unknown command. Try /help to see available commands.";
        }
      } else {
        botResponse = `Thanks for your message! You said: "${inputMessage}"\n\nTry /help to see what I can do! 😊`;
      }

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        from: "bot",
        text: botResponse,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botMessage]);
      setStats(prev => ({
        ...prev,
        messages: prev.messages + 1,
        commands: inputMessage.startsWith("/") ? prev.commands + 1 : prev.commands
      }));
    }, 800 + Math.random() * 1200);
  };

  if (!isRunning) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <Bot className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <h3 className="font-medium mb-2">Bot Preview</h3>
          <p className="text-sm">Start your bot to see live interactions</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-3 border-b bg-muted/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bot className="h-4 w-4 text-primary" />
            <span className="font-medium text-sm">{project.name}</span>
            <Badge variant="outline" className="text-xs">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-1" />
              Live
            </Badge>
          </div>
          <Button variant="ghost" size="sm" asChild>
            <a 
              href="https://t.me/Tg_oieieoorir_bot" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-xs"
            >
              Open @Tg_oieieoorir_bot
              <ExternalLink className="h-3 w-3 ml-1" />
            </a>
          </Button>
        </div>
        
        {/* Stats */}
        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            {stats.users}
          </div>
          <div className="flex items-center gap-1">
            <MessageCircle className="h-3 w-3" />
            {stats.messages}
          </div>
          <div className="flex items-center gap-1">
            <Activity className="h-3 w-3" />
            {stats.uptime}
          </div>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-3">
        <div className="space-y-3">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex gap-2",
                message.from === "bot" ? "justify-start" : "justify-end"
              )}
            >
              {message.from === "bot" && (
                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <Bot className="h-3 w-3 text-primary" />
                </div>
              )}
              
              <div
                className={cn(
                  "max-w-[80%] rounded-lg p-2 text-sm",
                  message.from === "bot"
                    ? "bg-muted text-foreground"
                    : message.isAdmin
                    ? "bg-yellow-100 dark:bg-yellow-900/20 text-foreground border border-yellow-200 dark:border-yellow-800"
                    : "bg-primary text-primary-foreground"
                )}
              >
                {message.isAdmin && (
                  <div className="flex items-center gap-1 mb-1">
                    <Crown className="h-3 w-3 text-yellow-600 dark:text-yellow-400" />
                    <span className="text-xs text-yellow-600 dark:text-yellow-400 font-medium">Admin</span>
                  </div>
                )}
                <div className="whitespace-pre-wrap">{message.text}</div>
                <div className="text-xs opacity-70 mt-1">
                  {message.timestamp.toLocaleTimeString()}
                </div>
              </div>
              
              {message.from === "user" && (
                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                  {message.isAdmin ? (
                    <Crown className="h-3 w-3 text-yellow-600" />
                  ) : (
                    <User className="h-3 w-3 text-primary" />
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-3 border-t">
        <div className="flex gap-2">
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Test your bot... try /help or /ping"
            className="text-sm"
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
          />
          <Button 
            size="sm" 
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || !isRunning}
          >
            <Send className="h-3 w-3" />
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          💡 Test commands: /ping, /help, /status, /admin (admin only)
        </p>
      </div>
    </div>
  );
}