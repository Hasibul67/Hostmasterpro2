import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertProjectSchema, insertPaymentSchema } from "@shared/schema";
import multer from "multer";

// Configure multer for file uploads
const upload = multer({ dest: 'uploads/' });

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email } = req.body;
      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // User routes
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const user = await storage.updateUser(id, updates);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Project routes
  app.get("/api/projects", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      
      if (userId) {
        const projects = await storage.getProjectsByUserId(userId);
        res.json(projects);
      } else {
        const projects = await storage.getAllProjects();
        res.json(projects);
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      
      // Check user's plan limits
      const user = await storage.getUser(projectData.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const userProjects = await storage.getProjectsByUserId(projectData.userId);
      const maxProjects = user.planType === "basic" ? 1 : user.planType === "pro" ? 4 : 0;
      
      if (userProjects.length >= maxProjects) {
        return res.status(400).json({ message: `Plan limit exceeded. ${user.planType} plan allows ${maxProjects} project(s)` });
      }

      // Simulate deployment
      const project = await storage.createProject({
        ...projectData,
        status: "building",
        deploymentUrl: `https://${projectData.name.toLowerCase().replace(/\s+/g, '-')}-${Math.random().toString(36).substring(2, 8)}.replit.app`,
        buildLogs: `Building ${projectData.language} project...\nInstalling dependencies...\nStarting application...\nDeployment successful!`,
        resourceUsage: JSON.stringify({
          cpu: Math.floor(Math.random() * 30) + 10,
          memory: Math.floor(Math.random() * 512) + 128,
          bandwidth: Math.floor(Math.random() * 1000) + 100
        })
      });

      // Simulate build process
      setTimeout(async () => {
        await storage.updateProject(project.id, { status: "online" });
      }, 2000);

      res.json(project);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const project = await storage.updateProject(id, updates);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json(project);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteProject(id);
      
      if (!success) {
        return res.status(404).json({ message: "Project not found" });
      }

      res.json({ message: "Project deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Deploy project
  app.post("/api/projects/:id/deploy", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }

      // Update project status to building
      await storage.updateProject(id, { 
        status: "building",
        buildLogs: `Starting deployment...\nPulling latest code...\nInstalling dependencies...\nBuilding application...`,
        lastDeployed: new Date()
      });

      // Simulate deployment process
      setTimeout(async () => {
        await storage.updateProject(id, { 
          status: "online",
          buildLogs: `Starting deployment...\nPulling latest code...\nInstalling dependencies...\nBuilding application...\nDeployment successful!\nApplication is now live at ${project.deploymentUrl}`
        });
      }, 3000);

      res.json({ message: "Deployment started" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Payment routes
  app.post("/api/payments", upload.single('screenshot'), async (req, res) => {
    try {
      const paymentData = insertPaymentSchema.parse({
        ...req.body,
        amount: parseInt(req.body.amount),
        userId: parseInt(req.body.userId),
      });

      if (req.file) {
        paymentData.screenshotUrl = `/uploads/${req.file.filename}`;
      }

      const payment = await storage.createPayment(paymentData);
      res.json(payment);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/payments", async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const status = req.query.status as string;
      
      if (userId) {
        const payments = await storage.getPaymentsByUserId(userId);
        res.json(payments);
      } else if (status === "pending") {
        const payments = await storage.getPendingPayments();
        res.json(payments);
      } else {
        const payments = await storage.getAllPayments();
        res.json(payments);
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/payments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const payment = await storage.updatePayment(id, updates);
      
      if (!payment) {
        return res.status(404).json({ message: "Payment not found" });
      }

      // If payment is approved, update user's plan
      if (updates.status === "approved") {
        await storage.updateUser(payment.userId, { planType: payment.planType });
      }

      res.json(payment);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Admin stats
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const projects = await storage.getAllProjects();
      const payments = await storage.getAllPayments();
      
      const stats = {
        totalUsers: users.length,
        activeProjects: projects.filter(project => project.status === "online").length,
        pendingPayments: payments.filter(payment => payment.status === "pending").length,
        revenue: payments
          .filter(payment => payment.status === "approved")
          .reduce((sum, payment) => sum + payment.amount, 0) / 100, // Convert cents to dollars
      };
      
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Serve uploaded files
  app.use('/uploads', (req, res, next) => {
    // In a real application, you'd serve files from a proper file storage service
    res.status(200).json({ message: "File access would be implemented with proper file storage" });
  });

  const httpServer = createServer(app);
  return httpServer;
}
