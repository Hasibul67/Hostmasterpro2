import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Server, Rocket, Check, CreditCard, Smartphone, Wallet } from "lucide-react";
import Navbar from "@/components/navbar";
import PaymentModal from "@/components/payment-modal";

export default function Payment() {
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<"basic" | "pro" | null>(null);

  const handleSelectPlan = (plan: "basic" | "pro") => {
    setSelectedPlan(plan);
    setPaymentModalOpen(true);
  };

  const plans = [
    {
      id: "basic" as const,
      name: "Basic Plan",
      price: "$3",
      period: "/month",
      description: "Perfect for individual developers",
      icon: Server,
      iconBg: "bg-blue-100",
      iconColor: "text-primary",
      features: [
        "Host 1 project",
        "99.9% uptime guarantee",
        "24/7 monitoring",
        "Basic support",
      ],
      buttonText: "Select Basic Plan",
      buttonClass: "bg-primary hover:bg-blue-600",
    },
    {
      id: "pro" as const,
      name: "Pro Plan",
      price: "$5",
      period: "/month",
      description: "Best value for multiple bots",
      icon: Rocket,
      iconBg: "bg-green-100",
      iconColor: "text-secondary",
      features: [
        "Host up to 4 projects",
        "99.9% uptime guarantee",
        "24/7 monitoring",
        "Priority support",
        "Advanced analytics",
      ],
      buttonText: "Select Pro Plan",
      buttonClass: "bg-primary hover:bg-blue-600",
      popular: true,
    },
  ];

  const paymentMethods = [
    {
      name: "Binance Pay",
      description: "Secure cryptocurrency payments",
      account: "510311493",
      icon: "₿",
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
    },
    {
      name: "Bkash",
      description: "Mobile financial service",
      account: "01715842614",
      icon: <Smartphone className="h-6 w-6" />,
      iconBg: "bg-pink-100",
      iconColor: "text-pink-600",
    },
    {
      name: "Nagad",
      description: "Digital financial service",
      account: "01715842614",
      icon: <Wallet className="h-6 w-6" />,
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            Deploy Any Project, Any Language
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Host websites, APIs, bots, and applications with reliable uptime, easy management, and affordable pricing. Get started in minutes.
          </p>
        </div>

        {/* Pricing Plans */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">Choose Your Plan</h3>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {plans.map((plan) => {
              const Icon = plan.icon;
              return (
                <Card
                  key={plan.id}
                  className={`shadow-lg transition-colors relative ${
                    plan.popular
                      ? "border-2 border-primary"
                      : "border-2 border-gray-200 hover:border-primary"
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-accent text-white px-4 py-2 text-sm font-semibold">
                        POPULAR
                      </Badge>
                    </div>
                  )}
                  <CardContent className="p-8">
                    <div className="text-center">
                      <div className={`inline-flex items-center justify-center w-16 h-16 ${plan.iconBg} rounded-full mb-4`}>
                        <Icon className={`h-8 w-8 ${plan.iconColor}`} />
                      </div>
                      <h4 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h4>
                      <div className="text-4xl font-bold text-primary mb-4">
                        {plan.price}
                        <span className="text-lg text-gray-600">{plan.period}</span>
                      </div>
                      <p className="text-gray-600 mb-6">{plan.description}</p>
                      <ul className="text-left space-y-3 mb-8">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-center">
                            <Check className="h-5 w-5 text-secondary mr-3 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                      <Button
                        className={`w-full py-3 px-6 font-semibold transition-colors ${plan.buttonClass}`}
                        onClick={() => handleSelectPlan(plan.id)}
                      >
                        {plan.buttonText}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Payment Methods */}
        <Card className="shadow-lg mb-12">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Payment Methods</CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              {paymentMethods.map((method) => (
                <div key={method.name} className="text-center p-6 bg-gray-50 rounded-lg">
                  <div className={`inline-flex items-center justify-center w-16 h-16 ${method.iconBg} rounded-full mb-4`}>
                    {typeof method.icon === "string" ? (
                      <span className={`text-2xl ${method.iconColor}`}>{method.icon}</span>
                    ) : (
                      <div className={method.iconColor}>{method.icon}</div>
                    )}
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">{method.name}</h4>
                  <p className="text-gray-600 text-sm mb-4">{method.description}</p>
                  <div className="bg-white p-3 rounded border text-sm font-mono text-gray-800">
                    {method.account}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-6 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                <CreditCard className="text-primary mr-2 h-5 w-5" />
                Payment Instructions
              </h4>
              <ol className="list-decimal list-inside space-y-2 text-gray-700">
                <li>Choose your preferred payment method from above</li>
                <li>Make the payment using the provided details</li>
                <li>Take a screenshot of your payment confirmation</li>
                <li>Send the screenshot to <a href="https://t.me/Rafi_00019" className="text-primary hover:underline">@Rafi_00019</a> on Telegram</li>
                <li>Your plan will be activated after verification (usually within 1-2 hours)</li>
              </ol>
            </div>
          </CardContent>
        </Card>
      </div>

      <PaymentModal
        isOpen={paymentModalOpen}
        onClose={() => setPaymentModalOpen(false)}
        selectedPlan={selectedPlan}
      />

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <Server className="mr-2 h-6 w-6" />
                BotHost Pro
              </h3>
              <p className="text-gray-400">
                Professional bot hosting service with reliable uptime and easy management.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Bot Hosting</a></li>
                <li><a href="#" className="hover:text-white">24/7 Monitoring</a></li>
                <li><a href="#" className="hover:text-white">Analytics</a></li>
                <li><a href="#" className="hover:text-white">Support</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Documentation</a></li>
                <li><a href="#" className="hover:text-white">FAQ</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
                <li><a href="https://t.me/Rafi_00019" className="hover:text-white">Telegram</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="space-y-2 text-gray-400">
                <p>📱 @Rafi_00019</p>
                <p>✉️ support@bothost.pro</p>
                <p>🕐 24/7 Support</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 BotHost Pro. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
