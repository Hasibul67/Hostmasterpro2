import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  telegramUsername: text("telegram_username"),
  planType: text("plan_type").notNull().default("none"), // "none", "basic", "pro"
  isAdmin: boolean("is_admin").notNull().default(false),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  language: text("language").notNull(), // "nodejs", "python", "php", "html", "go", "rust", "java"
  framework: text("framework"), // "express", "fastapi", "laravel", "react", "vue", etc.
  repositoryUrl: text("repository_url"),
  deploymentUrl: text("deployment_url"),
  status: text("status").notNull().default("offline"), // "online", "offline", "building", "error"
  lastDeployed: timestamp("last_deployed"),
  buildLogs: text("build_logs"),
  environmentVariables: text("environment_variables"), // JSON string of env vars
  customDomain: text("custom_domain"),
  isPublic: boolean("is_public").default(true),
  resourceUsage: text("resource_usage"), // JSON string with CPU, memory, bandwidth usage
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  planType: text("plan_type").notNull(), // "basic", "pro"
  amount: integer("amount").notNull(), // in cents
  paymentMethod: text("payment_method").notNull(), // "binance", "bkash", "nagad"
  screenshotUrl: text("screenshot_url"),
  status: text("status").notNull().default("pending"), // "pending", "approved", "rejected"
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  lastDeployed: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
});

export type User = typeof users.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
